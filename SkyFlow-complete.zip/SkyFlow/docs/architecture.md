# Architecture

```mermaid
flowchart LR
  Client --> OPS[Operations Service]
  OPS --> ODB[(Operations PostgreSQL)]
  OPS -- FlightDisrupted --> K[(Kafka)]
  K --> REC[Recovery Service]
  REC --> OPS
  REC --> RDB[(Recovery PostgreSQL)]
  REC -- RecoveryRecommendation --> K
  K -- OperationUpdated --> QRY[Query Service]
  QRY --> REDIS[(Redis)]
  Client --> QRY
```

The operations service is the source of truth. The recovery service is stateless apart from an audit history of recommendations. The query service builds an eventually consistent read model optimized for operational dashboards.
