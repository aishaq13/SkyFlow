package dev.skyflow.common.event;
import java.time.Instant; import java.util.UUID;
public record RecoveryRecommendationEvent(UUID eventId, UUID flightId, UUID recommendedGateId, UUID recommendedAircraftId, int projectedDelayMinutes, int score, String rationale, Instant createdAt) { public RecoveryRecommendationEvent { if(eventId==null) eventId=UUID.randomUUID(); if(createdAt==null) createdAt=Instant.now(); } }
