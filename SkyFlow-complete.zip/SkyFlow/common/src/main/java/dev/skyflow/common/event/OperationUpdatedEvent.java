package dev.skyflow.common.event;
import java.time.Instant; import java.util.UUID;
public record OperationUpdatedEvent(UUID eventId, UUID flightId, String flightNumber, String status, String gateCode, String aircraftTailNumber, int delayMinutes, Instant occurredAt) { public OperationUpdatedEvent { if(eventId==null) eventId=UUID.randomUUID(); if(occurredAt==null) occurredAt=Instant.now(); } }
