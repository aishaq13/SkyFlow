package dev.skyflow.common;
public final class Topics { private Topics() {} public static final String DISRUPTIONS="flight.disruptions.v1"; public static final String RECOMMENDATIONS="recovery.recommendations.v1"; public static final String OPERATIONS="operations.updates.v1"; }
