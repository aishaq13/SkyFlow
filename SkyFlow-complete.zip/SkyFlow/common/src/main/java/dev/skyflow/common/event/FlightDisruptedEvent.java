package dev.skyflow.common.event;
import java.time.Instant; import java.util.UUID;
public record FlightDisruptedEvent(UUID eventId, UUID flightId, String flightNumber, String airportCode, int delayMinutes, String reason, Instant occurredAt) { public FlightDisruptedEvent { if(eventId==null) eventId=UUID.randomUUID(); if(occurredAt==null) occurredAt=Instant.now(); } }
