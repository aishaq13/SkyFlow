package dev.skyflow.common.dto;
import java.time.Instant; import java.util.UUID;
public record FlightView(UUID id,String flightNumber,String origin,String destination,Instant scheduledDeparture,Instant scheduledArrival,String status,int delayMinutes,UUID gateId,UUID aircraftId) {}
