$ErrorActionPreference = "Stop"
git init
git branch -M main
git add .
git commit -m "Build SkyFlow airline operations simulator"
git remote add origin https://github.com/aishaq13/SkyFlow.git
git push -u origin main
